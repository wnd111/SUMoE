FB_BART_MAX_LEN = "1024"
FB_BART_FP16 = "True"
FB_BART_per_device_eval_batch_size = "10"


ALLEN_AI_MAX_SOURCE_LEN = "16384"
ALLEN_AI_MAX_TARGET_LEN = "1024"
ALLEN_AI_ATTENTION_WINDOW = "1024"
ALLEN_AI_per_device_eval_batch_size = "2"
ALLEN_AI_FP16 = "True"
